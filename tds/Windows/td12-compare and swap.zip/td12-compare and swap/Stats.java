public interface Stats {
  public int[] computeMinAndMax(final int[] ary);
}

