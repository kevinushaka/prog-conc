public interface Pile {
	public boolean push(int value);
	public int pop();
}
