/**
 * Class not to be modified
 */

/**
 * @author riveill
 *
 */
public class Simulate {
    public static void interrupt() {
        if (Math.random()<0.3) Thread.yield();
    }

}
