Aucun = 0
tkinter = 1
OpenCV = 2
PERSONNE = (0.0, 0.0, 1.0)
IMMOBILE = (1.0, 0.0, 0.0)
OBSTACLE = (0.0, 1.0, 0.0)
EMPTY = (1.0, 1.0, 1.0)
ARRIVEE = (0.0, 0.0, 0.0)
